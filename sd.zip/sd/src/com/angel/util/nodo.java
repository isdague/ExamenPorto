
package com.angel.util;

import java.util.ArrayList;

/**
 *
 * @author angel
 */
public class nodo {
    
    private nodo padre; 
    private ArrayList<nodo> hijo; 
    private String dato; 
    
    public nodo(String dato){
        this.dato=dato;
        this.padre = null;
        this.hijo = new ArrayList<>();
    }
    
    public nodo(){
        this.padre = null;
        this.hijo = new ArrayList<>();
    }

    public nodo getPadre() {
        return padre;
    }

    public void setPadre(nodo padre) {
        this.padre = padre;
    }

    public ArrayList<nodo> getHijo() {
        return hijo;
    }

    public void setHijo(ArrayList<nodo> hijo) {
        this.hijo = hijo;
    }   

    public String getDato() {
        return dato;
    }

    public void setDato(String dato) {
        this.dato = dato;
    }
}
