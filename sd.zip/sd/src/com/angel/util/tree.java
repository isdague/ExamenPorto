
package com.angel.util;

import java.util.ArrayList;

public class tree {
    
    private nodo root = null;
    
    public tree(){
        root = new nodo();
        root.setPadre(null);
        root.setHijo(new ArrayList<>());
        root.setDato("root");
    }
    
    public tree(String rootData){
        root = new nodo();
        root.setPadre(null);
        root.setHijo(new ArrayList<>());
        root.setDato(rootData);
    }

    public nodo getRoot() {
        return root;
    }

    public void setRoot(nodo root) {
        this.root = root;
    }
    
    public void addChild(nodo n1){
        if( this.root != null && this.root.getHijo() != null ){
            this.root.getHijo().add(n1);
        }
    }
}
