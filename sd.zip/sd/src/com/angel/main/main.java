
package com.angel.main;

import com.angel.util.nodo;
import com.angel.util.tree;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class main {
    public static void main(String [] args)
    {
        tree arbol = new tree("root");
        BufferedReader br = null;
        FileReader fr = null;
        String salida = "";
        try{
            fr = new FileReader("in.txt");
            br = new BufferedReader(fr); 
            String linea;
            linea = br.readLine();
            HashMap<String, Boolean> instalados = new HashMap<>();
            while( linea != null && !linea.equals("END")){
                String [] partes = linea.split(" ");
                if( partes.length > 0 ){
                    switch( partes[0] ){
                        case "DEPEND":
                            nodo hijoPrevio = null, hijo = null;
                            for( int i = ( partes.length-1 ); i>=1; i-- ){
                                hijo = new nodo(partes[i]);
                                if( hijoPrevio != null ){
                                    ArrayList<nodo> tmp = new ArrayList<>();
                                    tmp.add(hijoPrevio);
                                    hijoPrevio.setPadre(hijo);
                                    hijo.setHijo(tmp);
                                    hijo.setPadre(null);
                                }
                                hijoPrevio = hijo;
                            }
                            arbol.getRoot().getHijo().add(hijoPrevio);
                            salida+=linea+"\n";
                        break;
                        case "INSTALL":
                            salida+=linea+"\n";
                            String programa = (linea.split(" "))[1];
                            nodo n1 = buscaPrograma(arbol.getRoot(), programa);
                            if( n1 != null ){
                                salida = instalaDependencias(instalados, n1, salida);
                            }
                        break;
                        case "REMOVE":
                        break;
                    }                   
                }
                linea = br.readLine();
            }
            System.out.println(salida);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        } finally{
            try {
                fr.close();
                br.close();
            } catch (IOException ex) {
                Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        try{
            BufferedWriter bw = new BufferedWriter(new FileWriter("out.txt"));
            bw.write(salida);
            bw.close();
        } catch (IOException ex) {
            Logger.getLogger(main.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
    public static nodo buscaPrograma(nodo raiz, String busqueda){
        for( int i = 0; i< raiz.getHijo().size(); i++ ){
           if( raiz.getHijo().get(i).getDato().equals(busqueda) )
               return raiz.getHijo().get(i);
           else{
               buscaPrograma(raiz.getHijo().get(i), busqueda);
           }
        }
        return null;
    }
    
    public static String instalaDependencias(HashMap<String, Boolean> instalado, nodo instalar, String salida){
        if( instalar.getHijo() != null && !instalar.getHijo().isEmpty() 
                && instalado.get(instalar.getDato()) == null ){
            for( int i = 0; i<instalar.getHijo().size(); i++ ){
                salida+="\t"+"Intalling "+instalar.getDato()+"\n";
                instalado.put(instalar.getDato(), Boolean.TRUE);
                salida = instalaDependencias(instalado, instalar.getHijo().get(i), salida);
            }
        } else {
            salida+="\t"+"Intalling "+instalar.getDato()+"\n";
            instalado.put(instalar.getDato(), Boolean.TRUE);
        }
        return salida;
    }
    
    public static void imprimeArbol( nodo puntero ){
        if( puntero.getHijo() != null && !puntero.getHijo().isEmpty() ){
            for( int i = 0; i<puntero.getHijo().size(); i++ ){
                System.out.println(puntero.getHijo().get(i).getDato());
                imprimeArbol(puntero.getHijo().get(i));
            }
        }
    }
}
