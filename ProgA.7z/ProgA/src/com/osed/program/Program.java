/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.osed.program;

import com.osed.program.dto.Item;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author Osvaldo
 */
public class Program {

    public static final String SP = "   ";
    public static final String SL = "\n";

    /**
     * Set of installed items
     */
    Set<String> installedItems = new HashSet<>();

    /**
     * Dependencies of every item
     */
    Map<String, Item> dependentItems = new HashMap<>();

    public String execute(String sequence) {

        StringBuilder output = new StringBuilder();

        String[] commands = sequence.split("\n");

        for (int i = 0; i < commands.length; i++) {
            System.out.println(commands[i]);
            output.append(commands[i] + SL);

            if (commands[i] != null) {
                if (commands[i].contains("DEPEND")) {
                    String[] items = commands[i].split(" ");

                    depend(items);
                }

                if (commands[i].contains("INSTALL")) {
                    String[] items = commands[i].split(" ");

                    output.append(install(items[1]));

                }

                if (commands[i].contains("REMOVE")) {
                    String[] items = commands[i].split(" ");
                    output.append(remove(items[1]));
                }

                if (commands[i].contains("LIST")) {
                    output.append(list());
                }

            }

        }
        return output.toString();

    }

    private void depend(String[] items) {

        List<String> dependenciesList = new ArrayList<>();

        for (int j = 2; j < items.length; j++) {
            dependenciesList.add(items[j]);
        }
        Item dependentItem = new Item(items[1], dependenciesList);
        dependentItems.put(items[1], dependentItem);

    }

    public String install(String item) {

        StringBuilder output = new StringBuilder();

        if (installedItems.contains(item)) { // it is installed
            System.out.println(SP + item + " is already installed.");
            output.append(SP + item + " is already installed." + SL);
        } else { // it is not installed
            if (dependentItems.get(item) != null) { // it has dependencies
                Item dependencies = dependentItems.get(item);

                /**
                 * Check if a item's dependency is needed and install it
                 */
                for (String dep : dependencies.getDependenciesList()) {
                    if (!installedItems.contains(dep)) {
                        installedItems.add(dep);
                        System.out.println(SP + "Installing " + dep);
                        output.append(SP + "Installing " + dep + SL);
                    }
                }

            }

            /**
             * Install the item
             */
            installedItems.add(item);
            System.out.println(SP + "Installing " + item);
            output.append(SP + "Installing " + item + SL);
        }
        return output.toString();
    }

    public String remove(String item) {

        StringBuilder output = new StringBuilder();

        if (!installedItems.contains(item)) { // is not installed
            System.out.println(SP + item + " is not installed.");
            output.append(SP + item + " is not installed." + SL);
        } else { // it is installed

            boolean stillNeededItem = false;

            /**
             * Check if it is a dependency of another item
             */
            for (Map.Entry<String, Item> entry : dependentItems.entrySet()) {
                for (String dep : entry.getValue().getDependenciesList()) {
                    if (item.equals(dep)) {
                        stillNeededItem = true;
                        break;
                    }
                }
            }

            if (stillNeededItem) { // it is needed for another item
                System.out.println(SP + item + " is still needed.");
                output.append(SP + item + " is still needed." + SL);
            } else { // it is not needed for another item
                installedItems.remove(item);
                System.out.println(SP + " Removing " + item);
                output.append(SP + " Removing " + item + SL);

                List<String> itemDependencies = null;
                if (dependentItems.get(item) != null) {
                    itemDependencies = dependentItems.get(item).getDependenciesList();

                    /**
                     * Check if every item's dependency is a dependency of
                     * another item
                     */
                    for (String dependencyItem : itemDependencies) {

                        boolean stillNeededDependency = false;

                        for (Map.Entry<String, Item> entry : dependentItems.entrySet()) {

                            for (String dep : entry.getValue().getDependenciesList()) {
                                if (dependencyItem.equals(dep)) {
                                    if (installedItems.contains(entry.getKey())) {
                                        stillNeededDependency = true;
                                    }
                                    break;
                                }
                            }
                        }

                        /**
                         * Item's dependency is not a dependency of another item
                         */
                        if (!stillNeededDependency) {
                            installedItems.remove(dependencyItem);
                            System.out.println(SP + " Removing " + dependencyItem);
                            output.append(SP + " Removing " + dependencyItem + SL);
                        }
                    }

                }

            }

        }
        return output.toString();
    }

    private String list() {

        StringBuilder output = new StringBuilder();

        /**
         * Print all the installed items
         */
        for (String itemName : installedItems) {
            System.out.println(SP + itemName);
            output.append(SP + itemName + SL);
        }
        return output.toString();
    }

}
