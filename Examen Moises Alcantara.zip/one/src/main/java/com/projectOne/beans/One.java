package com.projectOne.beans;

public class One {
	
	public int validaComando(String arg) {
				
		String dep = "DEPEND";
		String ins = "INSTALL";
		String rem = "REMOVE";
		String lis = "LIST";
		
		if(arg.length()<10 && (arg.matches(dep) || arg.matches(ins) || arg.matches(rem) || arg.matches(lis))) {
			
			return 1;
			
		}
		else{
			return -1;
		}
		
		
	}
	
	
}
