package com.projectOne.one;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.projectOne.beans.One;

public class App {

	public static void main(String[] args){
		
		
		String nombre;

        Scanner comando = new Scanner(System.in);
        //nombre = comando.nextLine();
	    String []  cadena = null;
    	List<List<String>> listDepend = new ArrayList<List<String>>();		        	
    	List<List<String>> listInstall = new ArrayList<List<String>>();		        	
    	int hayDep =0;
    	int noDep =0;
    	int instalado = 0;
    	
        do {
		    System.out.print("");
		    nombre = comando.nextLine();
		    cadena = nombre. split(" ");
		    if(nombre.length()>80){
		    	//System.out.println("EXCEDE LOS 80 CARACTERES");	
		    }
		    else{
		    	
		    	One valComando = new One();
		    	
		        int val = valComando.validaComando(cadena[0]);
		                    
		        if(val == -1) {
		        	
		        	//System.out.println("Validar el comando (Debe tener menos de 10 caracteres y estar en mayúsculas - DEPEND, INSTALL, REMOVE, LIST)");
		        	
		        }
		        else {
		        	
		        	if(cadena[0].matches("DEPEND"))
		        	{
		        		
		        		if(noDep==0){
		        		
				        	listDepend.add(new ArrayList<String>());
				        	int i=0;				        	
				        	for( i=0; i<cadena.length-1; i++){
				        		listDepend.get(listDepend.size()-1).add(cadena[i+1]);
				        	}
				        	String depPrint = "";
				        	for( i=0; i<cadena.length-1; i++){
				        		depPrint += " "+listDepend.get(listDepend.size()-1).get(i);
				        	}
				        	
				        	System.out.println("DEPEND " + depPrint);
		        		}else {
		        			//System.out.println("Ya no puede haber dependencias...");

		        		}
		        	}
		        	else if(cadena[0].matches("INSTALL")) {
		        		noDep=1;
		        		listInstall.add(new ArrayList<String>());
		        		
		        		for(int i=0; i<listInstall.size(); i++){
		        			for(int j=0; j<listInstall.get(i).size(); j++){
		        				if(!listInstall.get(i).get(j).matches(cadena[1])) {
		        				}
		        				else {
			        				System.out.println(cadena[1]+ " is already installed ");
			        				instalado = 1;
			        				hayDep = 1;
		        				}
				        	}
		       
		        		}
		        		
		        		if(instalado == 0) {
		        		for(int i=0; i<listDepend.size(); i++){
		        			for(int j=0; j<listDepend.get(i).size(); j++){
		        				if(listDepend.get(i).get(j).matches(cadena[1])) {
		        					System.out.println("Installing... " + cadena[1]);
		        					for(int h=j; h<listDepend.get(i).size(); h++){
		        						listInstall.get(listInstall.size()-1).add(listDepend.get(i).get(h));
		        					}
		        					hayDep = 1;
		        				}
				        	}
		       
		        		}}
		        		
		        		instalado = 0;
		        		
		        		if(hayDep == 0) {
		        			
		        			listInstall.get(listInstall.size()-1).add(cadena[1]);
		        			System.out.println("Installing..." + cadena[1]);
		        		}
		        		hayDep = 0;
		        	}
		        	else if(cadena[0].matches("REMOVE")) {
		        		
		        		noDep=1;
		        		
		        		
		        		for(int i=0; i<listDepend.size(); i++){
		        			for(int j=0; j<listDepend.get(i).size(); j++){
		        				if(listDepend.get(i).get(j).matches(cadena[1])) {
		        					hayDep = 1;
		        					
		        					if(cadena[1].matches(listDepend.get(i).get(listDepend.get(i).size()-1))) {
		        						hayDep=0;
		        						break;
		        					}
		        					break;
		        				}
				        	}
		        		}
			        	
		        		
		        		if(hayDep != 1) {
			        		for(int i=0; i<listInstall.size(); i++){
			        			for(int j=0; j<listInstall.get(i).size(); j++){
			        				if(listInstall.get(i).get(j).matches(cadena[1])) {
			        				
			        					listInstall.get(i).remove(0);
				        				System.out.println("Removing " + cadena[1]);
						        	
			        				}
					        	}
			       
			        		}
		        		}
		        		else {
		        			
		        			System.out.println(cadena[1]+" is still needed");
		        		}
		        		
		        	}
		        	else if(cadena[0].matches("LIST")) {
		        		
		        		noDep=1;
		        		for(int i=0; i<listInstall.size(); i++){
		        			for(int j=0; j<listInstall.get(i).size(); j++){
		        				System.out.println(listInstall.get(i).get(j));
		        				}
		       
		        		}
		        		
		        	}
		        	
		        }
		    
		    }
        
		}while(!cadena[0].matches("END"));
        
        
		
	}
}
