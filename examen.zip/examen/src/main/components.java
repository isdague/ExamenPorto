package main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class components {
	
	private String componente;
	private List<String> dependencias;
	
	public components(  String[] comando){
		
		this.dependencias = new ArrayList<String>();
		
		List<String> temp = new ArrayList<String>();
		Collections.addAll(temp, comando);
		//System.out.println("temp long" + temp.size());
		temp.remove(0);
		this.componente = temp.get(0);
		temp.remove(0);
		
		for( String t : temp) {
			dependencias.add(t);
		}
		
		
	}
	/**
	 * @return the componente
	 */
	public String getComponente() {
		return componente;
	}
	/**
	 * @param componente the componente to set
	 */
	public void setComponente(String componente) {
		this.componente = componente;
	}
	/**
	 * @return the dependencias
	 */
	public List<String> getDependencias() {
		return dependencias;
	}
	/**
	 * @param dependencias the dependencias to set
	 */
	public void setDependencias(List<String> dependencias) {
		this.dependencias = dependencias;
	}
	

}
