/**
 * 
 */
package main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * @author stratoguy_mx
 *
 */
public class programa {
	
	static List<components> dependencias;
	static List<String> instalados;
	static List<String> depende;
	static String mainUni;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		 
		dependencias = new ArrayList<components>();
		instalados = new ArrayList<String>();
		Boolean ban = true;
		System.out.println("System Dependencies");
		while(ban) {
			BufferedReader bR = new BufferedReader(new InputStreamReader(System.in));
			try {
				String comando = bR.readLine().toUpperCase();
				String comandoArray[] = comando. split(" ");
				switch (comandoArray[0]) {
				case "DEPEND" :
					dependencias.add(new components(comandoArray));
					System.out.println(comando);
					//System.out.println(dependencias.size());
					break;
				case "INSTALL" :
					if(instalados.contains(comandoArray[1])) {
						System.out.println("\t"+comandoArray[1]+"is already installed.");
					}else {
						depende = new ArrayList<String>();
						buscaDepend(comandoArray[1]);
						depende.remove(comandoArray[1]);
						depende.add(comandoArray[1]);
						for (String inst : depende) {
							instalados.add(inst);
							System.out.println("\tInstalling "+inst);
						}	
					}
									
					break;
				case "REMOVE" :
					System.out.println(comando);
					if(instalados.contains(comandoArray[1])){
					List<String> depUn = buscaDependUnistall(comandoArray[1])  ;
				
					if(depUn.isEmpty()){
						instalados.remove(comandoArray[1]);
						System.out.println("\tRemoving "+ comandoArray[1]);
						List<String> uniDep = new ArrayList<String>();
						mainUni = comandoArray[1];
						for (components comp : dependencias) {
							if(comp.getComponente().equals(comandoArray[1]))
								uniDep = comp.getDependencias();
						}
						for(String s : uniDep) {
							 if(buscaDependUnistall(s).isEmpty()  || !instalados.contains(s)) {
								 instalados.remove(s);
									System.out.println("\tRemoving " + s);
							 }
						}
					}else {
						System.out.println("\t " + comandoArray[1] + " is still needed.");
					}
					}else
						System.out.println("\t" + comandoArray[1] +" is not installed.");
						
					
					break;
				case "LIST" :
					for( String s : instalados) {
						System.out.println("\t"+s);
					}
					//System.out.println(comando);
					break;
				case "END":
					ban = false;
					System.out.println(comando);
					break;
				
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		

	}
	
	private static void buscaDepend(String s) {
		for (components comp : dependencias) {
			if(!depende.contains(s) && !instalados.contains(s)) {
				depende.add(s);
			}
			if(comp.getComponente().equals(s)) {
				
				for (String dep : comp.getDependencias()) {
					buscaDepend(dep);
				}
			}
		}
		//return null;
	}

	public static List<String> buscaDependUnistall(String s) {
		
		List<String> dependenciasNec = new ArrayList<>();
		for (components comp : dependencias) {
			if(!comp.getComponente().equals(mainUni))
				if(comp.getDependencias().contains(s)){
					dependenciasNec.add(comp.getComponente());
				}
		}
		
		
		return dependenciasNec;
		
	}

}
