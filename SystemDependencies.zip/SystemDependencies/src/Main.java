import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.systemdependecies.managers.DependenciesManager;
import com.systemdependecies.managers.IntallerManager;

public class Main {

	public static void main(String[] args) {
		boolean inProcess = true;
		DependenciesManager dm = new DependenciesManager();
		IntallerManager im = new IntallerManager();
		Scanner scan = new Scanner(System.in);
		while(inProcess) {
			String command = scan.nextLine();
			String cleanCommand = command.replace("\t"," ");
			String[] commandSplit = cleanCommand.split(" ");
			
			if(commandSplit[0].equals("DEPEND")) {
				List<String> dependencies = new ArrayList<String>();
				for(int i = 2;i<commandSplit.length;i++) {
					dependencies.add(commandSplit[i]);
				}
				dm.setDependenciesToItem(commandSplit[1], dependencies);
				System.out.println(command);
			} 
			
			else if(commandSplit[0].equals("INSTALL")) {
				String itemName = commandSplit[1];
				List<String> dependencies = dm.getDependenciesByItemName(itemName);
				im.installItem(itemName, dependencies);
			} 
			
			else if(commandSplit[0].equals("REMOVE")) {
				String itemName = commandSplit[1];
				List<String> dependencies = dm.getDependenciesByItemName(itemName);
				im.removeItem(itemName, dependencies);
			}
			
			else if(commandSplit[0].equals("LIST")) {
				im.listInstalledItems();
			}
			
			else if(commandSplit[0].equals("END")) {
				inProcess = false;
				System.out.println("END");
			}
			
		}
		scan.close();
	}

}
