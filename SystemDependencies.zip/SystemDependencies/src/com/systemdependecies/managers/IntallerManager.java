package com.systemdependecies.managers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.systemdependecies.item.Item;

public class IntallerManager {
	
	private Map<String,Item> itemsInstalled = new HashMap<String, Item>();
	
	public void installItem(String itemName, List<String> dependencies) {
		if(dependencies!= null && !dependencies.isEmpty()) {
			for(String dependency: dependencies) {
				Item searchedDependencyItem = getItemInstalled(dependency);
				if(searchedDependencyItem==null) {
					searchedDependencyItem = new Item();
					searchedDependencyItem.setItemName(dependency);
					searchedDependencyItem.setDependency(true);
					searchedDependencyItem.setNumDependencies(1);
					itemsInstalled.put(dependency, searchedDependencyItem);
					System.out.println("Installing " + dependency);
				} else {
					updateDependency(dependency,1);
				}
			}
		}
		
		Item searchedItem = getItemInstalled(itemName);
		if(searchedItem==null) {
			searchedItem = new Item();
			searchedItem.setItemName(itemName);
			searchedItem.setDependency(false);
			searchedItem.setNumDependencies(0);
			itemsInstalled.put(itemName, searchedItem);
			System.out.println("Installing " + itemName);
		} else {
			System.out.println(itemName + " is already installed.");
		}
		
	}
	
	public void removeItem(String itemName, List<String> dependencies) {
		Item item = getItemInstalled(itemName);
		if(item!=null) {
			if(!item.isDependency()) {
				removeItemFromMap(itemName);
				System.out.println("Removing " + itemName);
				if(dependencies!=null && !dependencies.isEmpty()) {
					for(String dependency:dependencies) {
						Item itemDependency = getItemInstalled(dependency);
						removeDependency(itemDependency,2);
					}
				}
			} else {
				removeDependency(item,1);
			}
		} else {
			System.out.println(itemName + " is not installed.");
		}
	}
	
	private void removeDependency(Item item, int isDirect) { 
		if(item.getNumDependencies()==0) {
			removeItemFromMap(item.getItemName());
			System.out.println("Removing " + item.getItemName());
		} else {
			if(isDirect!=1) {
				updateDependency(item.getItemName(),-1);
			} else { 
				System.out.println(item.getItemName() + " is still needed.");
			}
		}
	}
	
	
	public void listInstalledItems() {
		for(Item item:itemsInstalled.values()) {
			System.out.println(item.getItemName());
		}
	}
	
	private void updateDependency(String itemName,int numDependencies) {
		Item item = itemsInstalled.get(itemName);
		item.setDependency(true);
		item.setNumDependencies(item.getNumDependencies()+ (numDependencies));
		itemsInstalled.remove(itemName);
		itemsInstalled.put(itemName, item);
	}
	
	private void removeItemFromMap(String itemName) {
		itemsInstalled.remove(itemName);
	}
	
	private Item getItemInstalled(String itemName) {
		Item item = itemsInstalled.get(itemName);
		return item;
	}
	

}
