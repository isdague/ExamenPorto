package com.systemdependecies.managers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DependenciesManager {
	
	private Map<String, List<String>> mapDependencies = new HashMap<>();
	
	public void setDependenciesToItem(String itemName,List<String> dependencies) {
		mapDependencies.put(itemName, dependencies);
	}
	
	public List<String> getDependenciesByItemName(String itemName) {
		return mapDependencies.get(itemName);
	}
	
}
