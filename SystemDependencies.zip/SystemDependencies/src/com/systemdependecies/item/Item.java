package com.systemdependecies.item;

public class Item {
	
	private String itemName;
	private boolean isDependency;
	private int numDependencies;
	
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public boolean isDependency() {
		return isDependency;
	}
	public void setDependency(boolean isDependency) {
		this.isDependency = isDependency;
	}
	public int getNumDependencies() {
		return numDependencies;
	}
	public void setNumDependencies(int numDependencies) {
		this.numDependencies = numDependencies;
	}
	
	
	

}
