package com.projectOne.one;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.projectOne.beans.One;

public class App {

	public static void main(String[] args){
		
		
		String nombre;

        Scanner comando = new Scanner(System.in);
        nombre = comando.nextLine();
	    String []  cadena = nombre. split(" ");
    	List<List<String>> listDepend = new ArrayList<List<String>>();		        	
    	List<List<String>> listInstall = new ArrayList<List<String>>();		        	
    	int hayDep =0;
    	int noDep =0;
    	listDepend.add(new ArrayList<String>());
    	listInstall.add(new ArrayList<String>());
    	
        do {
		    System.out.print("");
		    nombre = comando.nextLine();
		    cadena = nombre. split(" ");
		    if(nombre.length()>80){
		    	System.out.println("EXCEDE LOS 80 CARACTERES");	
		    }
		    else{
		    	
		    	One valComando = new One();
		    	
		        int val = valComando.validaComando(cadena[0]);
		                    
		        if(val == -1) {
		        	
		        	System.out.println("Validar el comando (Debe tener menos de 10 caracteres y estar en mayúsculas - DEPEND, INSTALL, REMOVE, LIST)");
		        	
		        }
		        else {
		        	
		        	if(cadena[0].matches("DEPEND"))
		        	{
		        		
		        		if(noDep==0){
		        		
				        	listDepend.add(new ArrayList<String>());
				        	
				        	for(int i=0; i<cadena.length-1; i++){
				        		listDepend.get(listDepend.size()-1).add(cadena[i+1]);
				        	}
				        	
				        	System.out.println(listDepend);
		        		}else {
		        			System.out.println("Ya no puede haber dependencias...");

		        		}
		        	}
		        	else if(cadena[0].matches("INSTALL")) {
		        		noDep=1;
		        		listInstall.add(new ArrayList<String>());
		        		
		        		
		        		for(int i=0; i<listDepend.size(); i++){
		        			for(int j=0; j<listDepend.get(i).size(); j++){
		        				//System.out.println(listDepend.get(i).get(j));
		        				if(listDepend.get(i).get(j).matches(cadena[1])) {
		        					System.out.println("Llamamos función de dependencias para... " + cadena[1]);
		        					
		        					for(int h=j; h<listDepend.get(i).size(); h++){
		        						listInstall.get(listInstall.size()-1).add(listDepend.get(i).get(h));
		        					}
		        					hayDep = 1;
		        				}
				        	}
		       
		        		}
		        		
		        		if(hayDep == 0) {
		        			
		        			listInstall.get(listInstall.size()-1).add(cadena[1]);
		        			System.out.println("Instalando..." + cadena[1]);
		        		}
		        		hayDep = 0;
		        	}
		        	else if(cadena[0].matches("REMOVE")) {
		        		
		        		noDep=1;
		        		for(int i=0; i<listInstall.size(); i++){
		        			for(int j=0; j<listInstall.get(i).size(); j++){
		        				if(!listInstall.get(i).get(j).matches(cadena[1])) {
		        				}
		        				else {
		        					listInstall.get(i).remove(0);
			        				System.out.println("Eliminando de la lista... " + cadena[1]);
					        	
		        				}
				        	}
		       
		        		}
		        		
		        	}
		        	else if(cadena[0].matches("LIST")) {
		        		
		        		noDep=1;
		        		for(int i=0; i<listInstall.size(); i++){
		        			for(int j=0; j<listInstall.get(i).size(); j++){
		        				System.out.println(listInstall.get(i).get(j));
		        				}
		       
		        		}
		        		
		        	}
		        	
		        }
		    
		    }
        
		}while(!cadena[0].matches("FIN"));
        
        
		
	}
}
