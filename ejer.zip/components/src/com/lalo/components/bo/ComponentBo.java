package com.lalo.components.bo;

import com.lalo.components.vo.Component;

public interface ComponentBo {

	boolean inputValidate(String entrada);
	
	String checkInput(String entrada);
	
	void showList();
	
	void addDependency(String entrada);
	
	void installComponent(String entrada);
	
	void install(String principal, boolean isParent);
	
	void removeComponent(String entrada);
	
	void remove(Component entrada,boolean isParent, Component componentParent);

}
