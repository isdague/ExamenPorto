package com.lalo.components.bo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import com.lalo.components.vo.Component;

public class ComponentBoImpl implements ComponentBo{

	static Set<String> stCommands;
	static{
		stCommands = new HashSet<String>();
		stCommands.add("DEPEND");
		stCommands.add("INSTALL");
		stCommands.add("REMOVE");
		stCommands.add("LIST");
	}
	private Map<String,Component> mpComponents = new  HashMap<>();
	
	@Override
	public boolean inputValidate(String entrada) {
		
		String comando = checkInput(entrada);		
		switch (comando) {
		case Component.TYPE_DEPEND:
			addDependency(entrada);
			break;
		case Component.TYPE_INSTALL:
			installComponent(entrada);
			break;
		case Component.TYPE_REMOVE:
			removeComponent(entrada);
			break;
		case Component.TYPE_LIST:
			showList();
			break;
		case Component.TYPE_EXIT:
			return false;
		default:
			//5515046028
			break;
		}
		return true;
	}
	@Override
	public void removeComponent(String entrada) {
		String array[] = entrada.split(Pattern.quote(" "));
		String principal = array[1];
		if(mpComponents.containsKey(principal)){
			Component principalComponent = mpComponents.get(principal);
			remove(principalComponent, true,new Component());
		}else
			System.out.println(principal+ " is not installed");
	}
	@Override
	public void remove(Component component, boolean isParent, Component componentParent){
		boolean canDelete=true;
		for (String key : mpComponents.keySet()) {
			if(mpComponents.get(key).getComponentParent().contains(component) && !mpComponents.get(key).equals(componentParent)){
				canDelete=false;
				break;
			}
		}
		if(canDelete){
			for (Component childComponent : component.getComponentParent()) {
				remove(childComponent,false,component);
			}
			System.out.println("Removing "+ component.getNameId());
			mpComponents.remove(component.getNameId());
		}else{
			if(isParent)
				System.out.println(component.getNameId()+" is still needed.");
		}
	}
	@Override
	public void installComponent(String entrada) {
		String array[] = entrada.split(Pattern.quote(" "));
		String principal = array[1];
		install(principal, true);
	}
	@Override
	public void install(String principal, boolean isParent) {
		if(!mpComponents.containsKey(principal)){
			addDependency("DEPEND "+ principal);
		}
		Component principalComponent = mpComponents.get(principal);
		if(!principalComponent.isInstalled()){
			if(!principalComponent.getComponentParent().isEmpty()){
				for (Component component : principalComponent.getComponentParent()) {
					install(component.getNameId(), false);
				}
			}
			System.out.println("Installing " + principalComponent.getNameId() );
			principalComponent.setInstalled(true);
		}
		else
		{	
			if (isParent)
				System.out.println(principalComponent.getNameId()+ " is already installed");
		}
	}
	@Override
	public void addDependency(String entrada) {
		String array[] = entrada.split(Pattern.quote(" "));
		String principal = array[1];
		if(!mpComponents.containsKey(principal)){
			mpComponents.put(principal, new Component(principal, new ArrayList<>()));
		}
		for (int i = 2; i < array.length; i++) {
			String component = array[i];
			if(!mpComponents.containsKey(component)){
				mpComponents.put(component, new Component(component, new ArrayList<>()));
			}
			if(!mpComponents.get(principal).getComponentParent().contains(mpComponents.get(component)))
				mpComponents.get(principal).getComponentParent().add(mpComponents.get(component));
		}
	}
	@Override
	public void showList() {
		for (String nameId : mpComponents.keySet()) {
			System.out.println(mpComponents.get(nameId).getNameId());
//			for (Component dependComponent : mpComponents.get(nameId).getComponentParent()) {
//				System.out.println(dependComponent.getNameId());
//			}
		}
		
	}
	@Override
	public String checkInput(String entrada) {
		if(entrada ==null || entrada.length()==0 || entrada.length() > 80){
			System.out.println("Strinig null or epty or > 80");
			return Component.TYPE_EROR;
		}
		String array[] = entrada.split(Pattern.quote(" "));
		if(array.length<2 && array[0].equals("END"))
			return Component.TYPE_EXIT;
		if(array.length<2 && array[0].equals("LIST"))
			return Component.TYPE_LIST;
		if(array.length<2){
			System.out.println("You need at least two strings");
			return Component.TYPE_EROR;
		}
		String comando = array[0];
		if(!stCommands.contains(comando)){
			System.out.println("Command not found");
			return Component.TYPE_EROR;
		}
		array=null;
		return comando;
	}

}
