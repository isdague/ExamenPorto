package com.lalo.components;

import java.util.Scanner;

import com.lalo.components.bo.ComponentBo;
import com.lalo.components.bo.ComponentBoImpl;

public class Components {

	public static void main(String[] args) {
		startProgram();
	}

	@SuppressWarnings("resource")
	private static void startProgram() {
		boolean salida=true;
		String entrada;
		ComponentBo component = new ComponentBoImpl();
		component.inputValidate("DEPEND TELNET TCPIP NETCARD");
		component.inputValidate("DEPEND TCPIP NETCARD");
		component.inputValidate("DEPEND DNS TCPIP NETCARD");
		component.inputValidate("DEPEND BROWSER TCPIP HTML");
		component.inputValidate("INSTALL NETCARD");
		component.inputValidate("INSTALL TELNET");
		component.inputValidate("INSTALL foo");
		component.inputValidate("REMOVE NETCARD");
		component.inputValidate("INSTALL BROWSER");
		component.inputValidate("INSTALL DNS");
		component.inputValidate("LIST");
		component.inputValidate("REMOVE TELNET");
		component.inputValidate("REMOVE NETCARD");
		component.inputValidate("REMOVE DNS");
		component.inputValidate("REMOVE NETCARD");
		component.inputValidate("INSTALL NETCARD");
		component.inputValidate("REMOVE TCPIP");
		component.inputValidate("REMOVE BROWSER");
		component.inputValidate("REMOVE TCPIP");
		component.inputValidate("LIST");
		
		while(salida){
			System.out.print("Input:");
			Scanner teclado = new Scanner(System.in);
			entrada = teclado.nextLine();
			salida = component.inputValidate(entrada);
		}
		System.out.println("Exit");
	}
}
