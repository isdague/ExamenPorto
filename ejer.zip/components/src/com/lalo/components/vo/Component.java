package com.lalo.components.vo;

import java.util.List;

public class Component {
	
	public final static String TYPE_DEPEND = "DEPEND";
	public final static String TYPE_INSTALL = "INSTALL";
	public final static String TYPE_REMOVE = "REMOVE";
	public final static String TYPE_LIST = "LIST";
	public final static String TYPE_EXIT = "EXIT";
	public final static String TYPE_EROR = "ERROR";

	private String nameId;
	private boolean installed;
	private List<Component> componentParent;
	
	public Component() {}

	public Component(String nameId, boolean installed, List<Component> componentParent) {
		this.nameId = nameId;
		this.installed = installed;
		this.componentParent = componentParent;
	}
	public Component(String nameId, List<Component> componentParent) {
		super();
		this.nameId = nameId;
		this.componentParent = componentParent;
	}

	public String getNameId() {
		return nameId;
	}

	public void setNameId(String nameId) {
		this.nameId = nameId;
	}

	public boolean isInstalled() {
		return installed;
	}

	public void setInstalled(boolean installed) {
		this.installed = installed;
	}

	public List<Component> getComponentParent() {
		return componentParent;
	}

	public void setComponentParent(List<Component> componentParent) {
		this.componentParent = componentParent;
	}
	
}
