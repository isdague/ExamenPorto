package org.ginger;


import org.ginger.enums.ActionsEnum;
import org.ginger.services.impl.DependenciesServicesImpl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Main {

    DependenciesServicesImpl dependenciesServices = new DependenciesServicesImpl();

    public static void main(String[] args) throws Exception {
        Main main = new Main();
        main.inputValues();
    }

    public void inputValues() throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Ingresa operacion ");
        String input = br.readLine();
        //System.out.println(input);

        String[] dependencies = new String[7];
        StringTokenizer tokens=new StringTokenizer(input);
        int position = 0;
        String action = tokens.nextToken();
        if(action != null && (!action.equalsIgnoreCase("END"))){
            while(tokens.hasMoreTokens()){
                dependencies[position] = tokens.nextToken();
                position += 1;
            }

            switch (action.toUpperCase()) {
                case "DEPEND": dependenciesServices.addDependencies(dependencies); break;
                case "INSTALL": dependenciesServices.installSoftware(dependencies[0]); break;
                case "REMOVE": dependenciesServices.removeSoftware(dependencies[0]); break;
                case "LIST": dependenciesServices.list(); break;
            }

            inputValues();
        } else if(action == null) {
            System.out.println("opcion no correcta");
            inputValues();
        } else if(action.equalsIgnoreCase("END")) {
            System.out.println("END");
        }
    }
}
