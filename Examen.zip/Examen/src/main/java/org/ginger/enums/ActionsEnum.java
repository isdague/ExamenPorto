package org.ginger.enums;

public enum ActionsEnum {
    DEPEND,
    INSTALL,
    REMOVE,
    LIST;
}
