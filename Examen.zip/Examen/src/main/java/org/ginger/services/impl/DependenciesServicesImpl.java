package org.ginger.services.impl;

import org.ginger.services.DependenciesServices;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;

public class DependenciesServicesImpl implements DependenciesServices {

    public static String[][] installedDependencies = new String[7][7];
    private static LinkedHashSet<String> installedSoftwareSet = new LinkedHashSet<String>();

    @Override
    public void addDependencies(final String[] dependencies) {
        for (int i = 0; i < installedDependencies.length; i++){
            if((installedDependencies[i][0] == null || installedDependencies[i][0].isEmpty()) ||
                installedDependencies[i][0].equalsIgnoreCase(dependencies[0])) {
                for (int j = 0; j < dependencies.length; j++) {
                    installedDependencies[i][j] = dependencies[j];
                }
                break;
            }
        }
    }

    @Override
    public void installSoftware(final String softwareToInstall) {
        if(!installedSoftwareSet.contains(softwareToInstall)) {
            for (int i = 0; i < installedDependencies.length; i++) {
                if (installedDependencies[i][0] != null && installedDependencies[i][0].equalsIgnoreCase(softwareToInstall)) {
                    for (int j = 0; j < installedDependencies[i].length; j++) {
                        if (installedDependencies[i][j] != null && (!installedSoftwareSet.contains(installedDependencies[i][j]))) {
                            System.out.println("installing " + installedDependencies[i][j].toUpperCase());
                            installedSoftwareSet.add(installedDependencies[i][j].toUpperCase());
                        }
                    }
                    break;
                }
            }
            if (!installedSoftwareSet.contains(softwareToInstall)) {
                System.out.println("installing " + softwareToInstall);
                installedSoftwareSet.add(softwareToInstall.toUpperCase());
            }
        } else{
            System.out.println(softwareToInstall + " is already installed.");
        }
    }

    @Override
    public void removeSoftware(final String softwareToRemove) {
        boolean flagToErase = true;
        for (int i = 0; i < installedDependencies.length; i++){
                for (int j = 1; j < installedDependencies[i].length; j++) {
                    if(installedDependencies[i][j] != null && installedDependencies[i][j].equalsIgnoreCase(softwareToRemove)) {
                        flagToErase = false;
                        System.out.println(installedDependencies[i][j].toUpperCase() + " is still needed ");
                        break;
                    }
                }
                break;
        }

        if(flagToErase) {
            System.out.println("Removing " + softwareToRemove);
            installedSoftwareSet.remove(softwareToRemove.toUpperCase());
        }
        //printDependencies();
    }

    @Override
    public void list() {
        Iterator itr = installedSoftwareSet.iterator();
        while (itr.hasNext()){
            System.out.println(itr.next());
        }
    }

    private void printDependencies() {
        for(int i = 0; i < 7; i++) {
            for(int j = 0; j < 7; j++) {
                    System.out.print(installedDependencies[i][j] + " ");
            }
            System.out.println();
        }
    }

}
