package org.ginger.services;

public interface DependenciesServices {

    abstract void addDependencies(final String[] dependencies);

    abstract void installSoftware(final String softwareToInstall);

    abstract void removeSoftware(final String softwareToRemove);

    abstract void list();
}
